import json
from avro.datafile import DataFileReader
import boto3
import urllib


def lambda_handler(event, context):
    # TODO implement
    print(event)
    source_bucket = event['Records'][0]['s3']['bucket']['name']
    key = urllib.unquote_plus(event['Records'][0]['s3']['object']['key'])
    print(source_bucket + " : " + key)
    return {
        'statusCode': 200,
        'body': json.dumps('Hello from Lambda!')
    }
